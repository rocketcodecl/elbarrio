<?php
return array (
  'publish_url' => 'https://elbarrio.lat/publish.php',
  'publish_token' => 'acc0674331d8f6e855e5a9e30a28842165598899c367c38d8239cc79f02d6a74',
);
